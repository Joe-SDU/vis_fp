# Create Interactive Dashboards with Streamlit and Python - Coursera Project

The course materials belong entirely to coursera. The answers are the only things that show my trials.

A huge thank you to the instructor: Snehan Kekre

Dataset: https://www.kaggle.com/crowdflower/twitter-airline-sentiment
