import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.graph_objects as go
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
from streamlit_apex_charts import line_chart, bar_chart, pie_chart, area_chart, radar_chart


DATA_URL = (
    "Tweets.csv"
)

st.title("Sentiment Analysis of Tweets about US Airlines")
st.sidebar.title("Sentiment Analysis of Tweets")
st.markdown("This application is a Streamlit dashboard used "
            "to analyze sentiments of tweets 🐦")
st.sidebar.markdown("This application is a Streamlit dashboard used "
            "to analyze sentiments of tweets 🐦")

@st.cache(persist=True)
def load_data():
    data = pd.read_csv(DATA_URL)
    data['tweet_created'] = pd.to_datetime(data['tweet_created'])
    return data

data = load_data()

import plotly.graph_objs as go


c1, c2, c3, c4, c5 = st.columns([0.05,1.5,0.2,1.5,0.2])
with c1:
    st.empty()
with c2:
 c1=[3,838,736,751,835,1049,2266,1919,781]
 c2 = [1,297,335,329,383,278,463,676,337]
 c3=[0,273,273,296,282,230,350,433,226]
 trace1 = go.Box(y=c1,fillcolor="#ff7500",marker_color="#ff7500",name="negative")
 trace2 = go.Box(y=c2,fillcolor="#16a951",marker={'color':"#16a951"},name="neutral")
 trace2 = go.Box(y=c2,fillcolor="#16a951",marker={'color':"#46a941"},name="positive")
 data1 = [trace1,trace2]
 layout = go.Layout(plot_bgcolor='#ffffff',width=500,height=500,title='箱型图')
 fig = go.Figure(data=data1,layout=layout)
 st.plotly_chart(fig, layout=layout)
with c3:
     st.empty()

with c4:
    #散点图
   c1=[3,838,736,751,835,1049,2266,1919,781]
   c2 = [1,297,335,329,383,278,463,676,337]
   c3=[0,273,273,296,282,230,350,433,226]
   trace1 = go.Scatter( x = [17,18,19,20,21,22,23,24],y=c1, mode = 'lines+markers',# 
        marker=dict(
        size=10,
        color = 'rgba(255, 182, 193, .9)',
        line = dict(
            width = 1,
            color = ['blue']
        )
        
        
      ),name="negative")
   trace2 = go.Scatter( x = [17,18,19,20,21,22,23,24],y=c2, mode = 'lines+markers',# 
        marker=dict(
        size=10,
        color = 'rgba(0, 255, 255, .8)',
        line = dict(
            width = 1,
            color = ['green']
        )
        
        
      ),name="neutral")
   trace3 = go.Scatter( x = [17,18,19,20,21,22,23,24],y=c3, mode = 'lines+markers',# 
        marker=dict(
        size=10,
        color = 'rgba(127, 255, 0, .8)',
        line = dict(
            width = 1,
            color = ['green']
        )
        
        
      ),name="positive")
   data1 = [trace1,trace2,trace3]
   layout = go.Layout(width=500,height=500,title='散点图')
   fig = go.Figure(data=data1,layout=layout)
   st.plotly_chart(fig, layout=layout)
    #漏斗图
    trace0 = go.Funnel(
        y = ["2015/2/16","2015/2/17",
"2015/2/18",
"2015/2/19",
"2015/2/20",
"2015/2/21",
"2015/2/22",
"2015/2/23",
"2015/2/24"
],
        x = [3,838,736,751,835,1049,2266,1919,781],
        textinfo = "value+percent initial",
        marker=dict(color=["deepskyblue"]*6),
        connector = {"line": {"color": "royalblue", "dash": "solid", "width": 3}})

    trace1 = go.Funnel(
        y = ["2015/2/16","2015/2/17",
"2015/2/18",
"2015/2/19",
"2015/2/20",
"2015/2/21",
"2015/2/22",
"2015/2/23",
"2015/2/24"
],
        x = [1,297,335,329,383,278,463,676,337],
        textinfo = "value+percent initial",
        marker=dict(color=["green"]*6),
        connector = {"line": {"color": "lightsalmon", "dash": "solid", "width": 3}})
    data = [trace0, trace1]
    layout = go.Layout(title='漏斗图')
    fig = go.Figure(data=data,layout=layout)
    st.plotly_chart(fig, layout=layout)


st.set_option('deprecation.showPyplotGlobalUse', False)
st.sidebar.subheader("Show random tweet")
random_tweet = st.sidebar.radio('Sentiment', ('positive', 'neutral', 'negative'))
st.sidebar.markdown(data.query("airline_sentiment == @random_tweet")[["text"]].sample(n=1).iat[0, 0])

st.sidebar.markdown("### Number of tweets by sentiment")
select = st.sidebar.selectbox('Visualization type', ['Bar plot', 'Pie chart'], key='1')
sentiment_count = data['airline_sentiment'].value_counts()
sentiment_count = pd.DataFrame({'Sentiment':sentiment_count.index, 'Tweets':sentiment_count.values})
if not st.sidebar.checkbox("Hide", True):
    st.markdown("### Number of tweets by sentiment")
    if select == 'Bar plot':
        fig = px.bar(sentiment_count, x='Sentiment', y='Tweets', color='Tweets', height=500)
        st.plotly_chart(fig)
    else:
        fig = px.pie(sentiment_count, values='Tweets', names='Sentiment')
        st.plotly_chart(fig)

st.sidebar.subheader("When and where are users tweeting from?")
hour = st.sidebar.slider("Hour to look at", 0, 23)
modified_data = data[data['tweet_created'].dt.hour == hour]
if not st.sidebar.checkbox("Close", True,key='7'):
    st.markdown("### Tweet locations based on time of day")
    st.markdown("%i tweets between %i:00 and %i:00" % (len(modified_data), hour, (hour + 1) % 24))
    st.map(modified_data)
    if st.sidebar.checkbox("Show raw data", False):
        st.write(modified_data)


st.sidebar.subheader("Total number of tweets for each airline")
each_airline = st.sidebar.selectbox('Visualization type', ['Bar plot', 'Pie chart'], key='2')
airline_sentiment_count = data.groupby('airline')['airline_sentiment'].count().sort_values(ascending=False)
airline_sentiment_count = pd.DataFrame({'Airline':airline_sentiment_count.index, 'Tweets':airline_sentiment_count.values.flatten()})
if not st.sidebar.checkbox("Close", True,key='8'):
    if each_airline == 'Bar plot':
        st.subheader("Total number of tweets for each airline")
        fig_1 = px.bar(airline_sentiment_count, x='Airline', y='Tweets', color='Tweets', height=500)
        st.plotly_chart(fig_1)
    if each_airline == 'Pie chart':
        st.subheader("Total number of tweets for each airline")
        fig_2 = px.pie(airline_sentiment_count, values='Tweets', names='Airline')
        st.plotly_chart(fig_2)


@st.cache(persist=True)
def plot_sentiment(airline):
    df = data[data['airline']==airline]
    count = df['airline_sentiment'].value_counts()
    count = pd.DataFrame({'Sentiment':count.index, 'Tweets':count.values.flatten()})
    return count


st.sidebar.subheader("Breakdown airline by sentiment")
choice = st.sidebar.multiselect('Pick airlines', ('US Airways','United','American','Southwest','Delta','Virgin America'))
if len(choice) > 0:
    st.subheader("Breakdown airline by sentiment")
    breakdown_type = st.sidebar.selectbox('Visualization type', ['Pie chart', 'Bar plot', ], key='3')
    fig_3 = make_subplots(rows=1, cols=len(choice), subplot_titles=choice)
    if breakdown_type == 'Bar plot':
        for i in range(1):
            for j in range(len(choice)):
                fig_3.add_trace(
                    go.Bar(x=plot_sentiment(choice[j]).Sentiment, y=plot_sentiment(choice[j]).Tweets, showlegend=False),
                    row=i+1, col=j+1
                )
        fig_3.update_layout(height=600, width=800)
        st.plotly_chart(fig_3)
    else:
        fig_3 = make_subplots(rows=1, cols=len(choice), specs=[[{'type':'domain'}]*len(choice)], subplot_titles=choice)
        for i in range(1):
            for j in range(len(choice)):
                fig_3.add_trace(
                    go.Pie(labels=plot_sentiment(choice[j]).Sentiment, values=plot_sentiment(choice[j]).Tweets, showlegend=True),
                    i+1, j+1
                )
        fig_3.update_layout(height=600, width=800)
        st.plotly_chart(fig_3)
st.sidebar.subheader("Breakdown airline by sentiment")
choice = st.sidebar.multiselect('Pick airlines', ('US Airways','United','American','Southwest','Delta','Virgin America'), key=0)
if len(choice) > 0:
    choice_data = data[data.airline.isin(choice)]
    fig_0 = px.histogram(
                        choice_data, x='airline', y='airline_sentiment',
                         histfunc='count', color='airline_sentiment',
                         facet_col='airline_sentiment', labels={'airline_sentiment':'tweets'},
                          height=600, width=800)
    st.plotly_chart(fig_0)

st.sidebar.header("Word Cloud")
word_sentiment = st.sidebar.radio('Display word cloud for what sentiment?', ('positive', 'neutral', 'negative'))
if not st.sidebar.checkbox("Close", True,key='9'):
    st.subheader('Word cloud for %s sentiment' % (word_sentiment))
    df = data[data['airline_sentiment']==word_sentiment]
    words = ' '.join(df['text'])
    processed_words = ' '.join([word for word in words.split() if 'http' not in word and not word.startswith('@') and word != 'RT'])
    wordcloud = WordCloud(stopwords=STOPWORDS, background_color='white', width=800, height=640).generate(processed_words)
    plt.imshow(wordcloud)
    plt.xticks([])
    plt.yticks([])
    st.pyplot()